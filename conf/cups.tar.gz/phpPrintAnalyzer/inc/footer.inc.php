<?php
/**universal
 * Fichier contenant le pied de page du site
 * 
 * @author Thomas Pequet
 * @version	1.0
 */
?>
&copy; Copyright Thomas Pequet / F�vrier 2004
</CENTER>

</BODY>
</HTML>