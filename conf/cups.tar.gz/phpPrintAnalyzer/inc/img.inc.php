<?php
/**universal
 * Fichier contenant la d�finition globale des images
 * 
 * @author Thomas Pequet
 * @version	1.0
 */
 
// Images communes � toutes les pages
DEFINE("IMAGE_IMPRIMANTE",	"<IMG SRC=\"".$rep_par_rapport_racine."img/printer.gif\" WIDTH=\"45\" HEIGHT=\"40\" BORDER=\"0\" HSPACE=\"0\" VSPACE=\"2\" ALIGN=\"absmiddle\">");	
DEFINE("IMAGE_STATS",		"<IMG SRC=\"".$rep_par_rapport_racine."img/stats.gif\" WIDTH=\"23\" HEIGHT=\"30\" BORDER=\"0\" HSPACE=\"6\" VSPACE=\"2\" ALIGN=\"absmiddle\">");	

?>
